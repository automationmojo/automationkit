"""
.. module:: coordinators
    :platform: Darwin, Linux, Unix, Windows
    :synopsis: Contains different coordinator objects. Coordinators are used to manage interoperability
               for classes or groups of devices.

.. moduleauthor:: Myron Walker <myron.walker@gmail.com>
"""

__author__ = "Myron Walker"
__copyright__ = "Copyright 2020, Myron W Walker"
__credits__ = []
__version__ = "1.0.0"
__maintainer__ = "Myron Walker"
__email__ = "myron.walker@gmail.com"
__status__ = "Development" # Prototype, Development or Production
__license__ = "MIT"
