
StrSvcId = str
StrSvcType = str
StrSubId = str
